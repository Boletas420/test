echo "The third character is 'T'."
